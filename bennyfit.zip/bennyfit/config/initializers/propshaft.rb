Rails.application.config.assets.paths << Rails.root.join("app/assets/builds")
