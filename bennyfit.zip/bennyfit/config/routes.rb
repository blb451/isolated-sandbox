Rails.application.routes.draw do
  namespace :api, defaults: { format: :json } do
    resources :users, only: [ :index, :show ] do
      member do
        get :points
      end
      resources :redemptions, only: [ :index, :create, :destroy ]
    end
    resources :rewards, only: [ :index ]
  end
  get "*path", to: "home#index", constraints: ->(request) { !request.xhr? && !request.format.html? }
  root "home#index"
end
