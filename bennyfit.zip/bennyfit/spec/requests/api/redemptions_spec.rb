require 'rails_helper'

RSpec.describe "Api::Redemptions", type: :request do
  include Api::RedemptionsHelper
  let!(:user) { User.create!(name: 'Test User', points: 1000) }
  let!(:reward) { Reward.create!(name: 'Test Reward', points_required: 100) }

  describe "POST /create" do
    context "valid params" do
      it "creates a redemption" do
        expect {
          post api_user_redemptions_path(user_id: user.id), params: { reward_id: reward.id }
        }.to change { user.reload.points }.by(-100)

        expect(response).to have_http_status(:created)
        expect(user.redemptions.count).to eq(1)

        redemption = Redemption.find(json_response['id'])
        expect(redemption.reward_snapshot).to include(reward.name)
        expect(redemption.points_spent).to eq(reward.points_required)
        expect(redemption.cancellable_until).to be_within(1.second).of(cancellation_window.from_now)
      end
    end

    context "invalid params" do
      it "returns not found if there is no user" do
        post api_user_redemptions_path(user_id: 999), params: { reward_id: reward.id }
        expect(response).to have_http_status(:not_found)
      end

      it "returns not found if there is no reward" do
        post api_user_redemptions_path(user_id: user.id), params: { reward_id: 999 }
        expect(response).to have_http_status(:not_found)
      end

      it "returns forbidden if the user doesn't have enough points" do
        expensive_reward = Reward.create!(name: 'Test Reward', points_required: 2000)
        post api_user_redemptions_path(user_id: user.id), params: { reward_id: expensive_reward.id }
        expect(json_response['error']).to include(error_messages[:insufficient_points])
        expect(response).to have_http_status(:forbidden)
      end
    end
  end

  describe "DELETE /destroy" do
    it "destroys a redemption" do
      redemption = user.redemptions.create!(reward: reward)
      expect {
        delete api_user_redemption_path(user_id: user.id, id: redemption.id)
      }.to change { user.reload.points }.by(reward.points_required)

      expect(response).to have_http_status(:no_content)
      expect(user.redemptions.count).to eq(0)
    end

    it "handles cancellation window expiration" do
      Timecop.freeze do
        redemption = user.redemptions.create!(
          reward: reward,
          cancellable_until: 0.5.seconds.from_now
        )

        Timecop.travel(0.6.seconds.from_now) do
          delete api_user_redemption_path(user_id: user.id, id: redemption.id)
          expect(json_response['error']).to include(error_messages[:cancellation_window_expired])
          expect(response).to have_http_status(:forbidden)
        end
      end
    end
  end
end
