require 'rails_helper'

RSpec.describe "Api::Bases", type: :request do
end
