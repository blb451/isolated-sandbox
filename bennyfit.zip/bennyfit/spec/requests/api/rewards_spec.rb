require 'rails_helper'

RSpec.describe "Api::Rewards", type: :request do
  let!(:reward) { Reward.create!(name: 'Reward', points_required: 100) }
  let!(:reward2) { Reward.create!(name: 'Reward2', points_required: 200) }
  describe "GET /index" do
    it "returns http success" do
      get api_rewards_path
      expect(response).to have_http_status(:success)
      expect(json_response.size).to eq(2)
    end
  end
end
