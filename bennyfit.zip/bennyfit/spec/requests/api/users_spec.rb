require 'rails_helper'

RSpec.describe "Api::Users", type: :request do
  let!(:user) { User.create!(name: 'Sue', points: 1000) }
  let!(:user2) { User.create!(name: 'Reed', points: 2000) }
  describe "GET /index" do
    it "returns http success" do
      get api_users_path
      expect(response).to have_http_status(:success)
      expect(json_response.size).to eq(2)
      expect(json_response.map { |u| u['name'] }).to eq([ 'Sue', 'Reed' ])
    end
  end

  describe "GET /show" do
    context 'with valid id' do
      it "returns user with redemptions" do
        get api_user_path(user.id)
        expect(response).to have_http_status(:success)
        expect(json_response['id']).to eq(user.id)
        expect(json_response['redemptions'].size).to eq(0)
      end
    end

    context 'with invalid id' do
      it "returns not found" do
        get api_user_path(999)
        expect(response).to have_http_status(:not_found)
        expect(json_response['error']).to include('User not found')
      end
    end
  end

  describe "GET /points" do
    it "returns user points" do
      get points_api_user_path(user.id)
      expect(response).to have_http_status(:success)
      expect(json_response['points']).to eq(user.points)
    end
    it "returns not found for invalid user" do
      get points_api_user_path(999)
      expect(response).to have_http_status(:not_found)
    end
  end
end
