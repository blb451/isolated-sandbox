require 'rails_helper'

RSpec.describe Api::RewardsHelper, type: :helper do
end
