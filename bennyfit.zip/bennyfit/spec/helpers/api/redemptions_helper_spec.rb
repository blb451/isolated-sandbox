require 'rails_helper'

RSpec.describe Api::RedemptionsHelper, type: :helper do
end
