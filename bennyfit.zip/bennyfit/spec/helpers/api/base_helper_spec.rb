require 'rails_helper'

RSpec.describe Api::BaseHelper, type: :helper do
end
