require 'rails_helper'

RSpec.describe Redemption, type: :model do
  describe 'validations and callbacks' do
    let(:user) { User.create!(name: 'John', points: 100) }
    let(:reward) { Reward.create!(name: 'Reward', points_required: 100) }
    let(:redemption) { Redemption.new(user: user, reward: reward, cancellable_until: 2.minutes.from_now) }

    it 'is valid with valid attributes' do
      expect(redemption).to be_valid
    end

    it 'captures a snapshot of the reward on create' do
      redemption.save!
      expect(redemption.points_spent).to eq(reward.points_required)
      expect(redemption.reward_snapshot).to eq(reward.to_json)
    end

    it 'sets cancellable_until to nil by default' do
      redemption = Redemption.new(user: user, reward: reward)
      expect(redemption.cancellable_until).to be_nil
    end

    it 'does not update the snapshot when the reward changes' do
      redemption.save!
      original_snapshot = redemption.reward_snapshot
      reward.update!(points_required: 200)
      expect(redemption.reload.reward_snapshot).to eq(original_snapshot)
      expect(redemption.reload.points_spent).to_not eq(reward.points_required)
    end
  end

  describe '#cancellable?' do
    let(:user) { User.create!(name: 'John', points: 100) }
    let(:reward) { Reward.create!(name: 'Reward', points_required: 100) }
    let(:redemption) { Redemption.create!(user: user, reward: reward, cancellable_until: 2.minutes.from_now) }

    it 'returns true when within the cancellation window' do
      expect(redemption.cancellable?).to be true
    end

    it 'returns false when outside the cancellation window' do
      Timecop.freeze do
        redemption.update!(cancellable_until: 2.minutes.ago)
        expect(redemption.cancellable?).to be false
      end
    end

    it 'returns false after the cancellation window expires' do
      Timecop.freeze do
        redemption.update!(cancellable_until: 1.minute.from_now)
        expect(redemption.cancellable?).to be true

        # Travel forward in time just past the cancellation window
        Timecop.travel(61.seconds.from_now) do
          expect(redemption.cancellable?).to be false
        end
      end
    end

    it 'returns true when no cancellation window is set' do
      redemption.update!(cancellable_until: nil)
      expect(redemption.cancellable?).to be true
    end
  end
end
