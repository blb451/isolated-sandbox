require 'rails_helper'

RSpec.describe Reward, type: :model do
    let(:reward) { Reward.create!(name: 'Reward', points_required: 100) }

    describe 'validations' do
        it 'is valid with valid attributes' do
            expect(reward).to be_valid
        end

        it 'is not valid without a name' do
            reward.name = nil
            expect(reward).to_not be_valid
        end

        it 'is not valid without points_required' do
            reward.points_required = nil
            expect(reward).to_not be_valid
        end

        it 'is not valid with zero points_required' do
            reward.points_required = 0
            expect(reward).to_not be_valid
        end

        it 'is not valid with negative points_required' do
            reward.points_required = -1
            expect(reward).to_not be_valid
        end
    end
end
