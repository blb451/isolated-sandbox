import '@testing-library/jest-dom';

// Mock any global objects or functions your tests might need
global.IS_REACT_ACT_ENVIRONMENT = true;
