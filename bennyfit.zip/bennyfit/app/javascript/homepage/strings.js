export default {
  homePageTitle: "BennyFits & Rewards",
  loadingUsers: "Loading users...",
  loadingUserPoints: "Loading user points...",
  errors: {
    noUsers: "No users found",
    failedToFetchUsers: "Failed to fetch users",
  },
};
