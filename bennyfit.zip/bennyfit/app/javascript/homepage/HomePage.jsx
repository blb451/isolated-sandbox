import { useState } from "react";
import {
  Tabs,
  defaultTabLabel,
  RedemptionHistory,
  BrowseRewards,
} from "../components/Tabs";
import { useUser } from "./hooks/use-user";
import strings from "./strings";

/**
 * Main App component
 * @returns {JSX.Element} The HomePage component
 */
export default function HomePage() {
  const { error, users, setPoints, handleUserChange, selectedUserId, loading } =
    useUser();
  const [activeTab, setActiveTab] = useState(defaultTabLabel);
  const user = users?.find((user) => user.id === selectedUserId);

  return (
    <div data-testid="homepage-container" style={{ minHeight: "100vh" }}>
      <header
        style={{
          borderBottomWidth: "1px",
          borderBottomStyle: "solid",
          borderColor: "black",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "16px",
        }}
      >
        <h1 data-testid="homepage-title">{strings.homePageTitle}</h1>
        {error ? <div data-testid="homepage-error-message">{error}</div> : null}
        {loading ? (
          <div data-testid="homepage-loading-message">
            {strings.loadingUsers}
          </div>
        ) : null}
        {users.length > 0 ? (
          <UserDropdown
            user={user}
            users={users}
            handleUserChange={handleUserChange}
            selectedUserId={selectedUserId}
          />
        ) : (
          <div data-testid="homepage-no-users-message">
            {strings.errors.noUsers}
          </div>
        )}
      </header>
      <main style={{ padding: "2em 1em" }}>
        <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />
        <div style={{ marginTop: "0.5rem" }}>
          {activeTab === defaultTabLabel ? (
            <BrowseRewards user={user} handleUpdatePoints={setPoints} />
          ) : (
            <RedemptionHistory user={user} handleUpdatePoints={setPoints} />
          )}
        </div>
      </main>
    </div>
  );
}

const UserDropdown = ({ user, users, handleUserChange, selectedUserId }) => {
  return (
    <div data-testid="user-points-container">
      <select
        data-testid="user-dropdown"
        onChange={(e) => handleUserChange(e.target.value)}
        value={selectedUserId}
      >
        {users.map((user) => (
          <option key={user.id} value={user.id}>
            {user.name}
          </option>
        ))}
      </select>
      {user ? (
        <p
          data-testid="user-points-value"
          style={{ fontWeight: "bold", fontSize: "24px" }}
        >
          {user?.points?.toLocaleString() ?? 0}
        </p>
      ) : (
        <p>{strings.loadingUserPoints}</p>
      )}
    </div>
  );
};
