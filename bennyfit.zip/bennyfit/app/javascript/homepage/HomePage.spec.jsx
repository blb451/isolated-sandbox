import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import React from "react";
import HomePage from "./HomePage";
import strings from "./strings";
import { mockUsers, mockRewards, mockRedemptions } from "../mockData";
import { tabLabels, getTestLabelId } from "../components/Tabs";

beforeEach(() => {
  global.fetch = vi.fn((url) => {
    if (url === "/api/users") {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockUsers),
      });
    }

    if (url.includes("/api/users/") && url.endsWith("/points")) {
      const userId = url.split("/")[3];
      const user = mockUsers.find((u) => u.id === parseInt(userId));
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(user?.points ?? 0),
      });
    }

    if (url === "/api/rewards") {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockRewards),
      });
    }

    if (url.includes("/api/users/") && url.includes("/redemptions")) {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockRedemptions),
      });
    }

    return Promise.resolve({
      ok: true,
      json: () => Promise.resolve({}),
    });
  });
});

describe("HomePage", () => {
  it("shows error message when users fail to load", async () => {
    global.fetch = vi.fn(() =>
      Promise.reject(new Error("Failed to fetch users"))
    );

    const originalError = console.error;
    console.error = vi.fn();

    render(<HomePage />);

    await waitFor(() => {
      expect(screen.getByTestId("homepage-error-message")).toHaveTextContent(
        strings.errors.failedToFetchUsers
      );
    });

    console.error = originalError;
  });

  it("handles loading state", async () => {
    const originalFetch = global.fetch;
    global.fetch = vi.fn((url) => {
      if (url === "/api/users") {
        return Promise.resolve({
          ok: false,
          status: 500,
          json: () => Promise.resolve({ error: "Server error" }),
        });
      }
      return originalFetch(url);
    });

    const originalError = console.error;
    console.error = vi.fn();

    render(<HomePage />);

    expect(screen.getByTestId("homepage-title")).toHaveTextContent(
      strings.homePageTitle
    );

    await waitFor(() => {
      expect(screen.getByTestId("homepage-loading-message")).toHaveTextContent(
        strings.loadingUsers
      );
    });

    expect(screen.getByTestId("homepage-no-users-message")).toHaveTextContent(
      strings.errors.noUsers
    );

    global.fetch = originalFetch;
    console.error = originalError;
  });

  it("renders the app title and user points for the first mock user", async () => {
    render(<HomePage />);
    expect(screen.getByTestId("homepage-title")).toHaveTextContent(
      strings.homePageTitle
    );

    await waitFor(() => {
      expect(screen.queryByText(strings.loadingUsers)).not.toBeInTheDocument();
    });

    mockUsers.forEach((user) => {
      expect(screen.getByText(user.name)).toBeInTheDocument();
    });

    const userPointsValue = screen.getByTestId("user-points-value");
    expect(userPointsValue.textContent).toBe(
      mockUsers[0].points.toLocaleString()
    );
  });

  it("goes through the dropdown successfully", async () => {
    render(<HomePage />);
    await waitFor(() => {
      expect(
        screen.queryByTestId("homepage-loading-message")
      ).not.toBeInTheDocument();
    });
    const dropdown = screen.getByTestId("user-dropdown");
    fireEvent.change(dropdown, { target: { value: mockUsers[1].id } });
    expect(screen.getByText(mockUsers[1].name)).toBeInTheDocument();
    expect(screen.getByTestId("user-points-value")).toHaveTextContent(
      mockUsers[1].points.toLocaleString()
    );
  });

  describe("tabs", () => {
    it("renders the tabs", async () => {
      render(<HomePage />);
      await waitFor(() => {
        expect(
          screen.queryByTestId("homepage-loading-message")
        ).not.toBeInTheDocument();
      });
      for (const label of tabLabels) {
        expect(screen.getByTestId(getTestLabelId(label))).toBeInTheDocument();
      }
    });
    it("handles tab selection", async () => {
      render(<HomePage />);
      await waitFor(() => {
        expect(
          screen.queryByTestId("homepage-loading-message")
        ).not.toBeInTheDocument();
      });
      await waitFor(() => {
        expect(screen.getByTestId("user-points-value")).toBeInTheDocument();
      });

      const redemptionButton = screen.getByTestId(getTestLabelId(tabLabels[1]));
      fireEvent.click(redemptionButton);

      await waitFor(() => {
        const redemptionItems = screen.getAllByTestId(/^redemption-item-\d+$/);
        expect(redemptionItems).toHaveLength(mockRedemptions.length);

        const redemptionNames = screen.getAllByTestId("redemption-name");
        const redemptionPoints = screen.getAllByTestId("redemption-points");

        mockRedemptions.forEach((redemption, index) => {
          expect(redemptionNames[index]).toHaveTextContent(
            redemption.parsed_reward_snapshot.name
          );
          expect(redemptionPoints[index]).toHaveTextContent(
            `-${redemption.points_spent} points`
          );
        });
      });

      const browseButton = screen.getByTestId(getTestLabelId(tabLabels[0]));
      fireEvent.click(browseButton);

      await waitFor(() => {
        const browseItems = screen.getAllByTestId(/^reward-card-\d+$/);
        expect(browseItems).toHaveLength(mockRewards.length);

        const rewardNames = screen.getAllByTestId("reward-name");
        const rewardPoints = screen.getAllByTestId("reward-points-required");

        mockRewards.forEach((reward, index) => {
          expect(rewardNames[index]).toHaveTextContent(reward.name);
          expect(rewardPoints[index]).toHaveTextContent(
            `${reward.points_required} points`
          );
        });
      });
    });
  });
});
