import { useEffect, useState, useCallback } from "react";

/**
 * Custom hook for managing user state
 * I typically like to use these as a way of abstracting logic for mutations and queries
 * from the React components, if not in a hook, I will usually have a utils file for
 * handling such logic
 * @returns {Object} An object containing user and points state management
 */
export function useUser() {
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // I seeded the db with a couple users to allow for variety with how the demo
    // can be interacted with
    async function fetchUsers() {
      try {
        const response = await fetch("/api/users");
        if (!response.ok) throw new Error(strings.errors.failedToFetchUsers);

        const data = await response.json();
        setUsers(data);
        if (!Array.isArray(data) || data.length === 0)
          throw new Error(strings.errors.noUsers);

        setSelectedUserId(data[0]?.id || null);
      } catch (error) {
        console.error(error.message);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    fetchUsers();
  }, []);

  const handleUserChange = (userId) => setSelectedUserId(parseInt(userId));
  const setPoints = useCallback(
    (newPoints) => {
      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === selectedUserId ? { ...user, points: newPoints } : user
        )
      );
    },
    [selectedUserId]
  );

  return { error, handleUserChange, loading, selectedUserId, setPoints, users };
}
