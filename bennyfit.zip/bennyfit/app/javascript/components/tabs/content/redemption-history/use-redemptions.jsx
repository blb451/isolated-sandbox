import { useState, useEffect, useMemo } from "react";
import { fetchUserPoints } from "../utils/api/queries";
import strings from "./strings";

/**
 * Custom hook for managing redemptions
 * @param {Object} user - The user object
 * @param {function} handleUpdatePoints - Function to update points
 * @returns {Object} An object containing redemptions and cancelRedemption function
 */
export function useRedemptions({ user, handleUpdatePoints }) {
  const [rawRedemptions, setRawRedemptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!user) return;
    async function fetchRedemptions() {
      try {
        setLoading(true);
        const response = await fetch(`/api/users/${user?.id}/redemptions`);
        if (!response.ok)
          throw new Error(strings.errors.failedToFetchRedemptions);

        const data = await response.json();
        setRawRedemptions(data);
      } catch (error) {
        console.error(error.message);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    fetchRedemptions();
  }, [user?.id]);

  // Memoize the data to prevent unnecessary re-renders after transforms
  const redemptions = useMemo(
    () => transformRedemptions(rawRedemptions),
    [rawRedemptions]
  );

  return {
    cancelRedemption: (redemptionId) =>
      cancelRedemption({
        handleUpdatePoints,
        redemptionId,
        setRawRedemptions,
        userId: user?.id,
      }),
    error,
    loading,
    redemptions,
  };
}

/**
 * Function to cancel a redemption
 * Also update user points in the ui after reverting the redemptions array
 * @param {number} redemptionId - The id of the redemption to cancel
 * @param {number} userId - The id of the user
 * @param {function} handleUpdatePoints - Function to update points
 * @param {function} setRawRedemptions - Function to update redemptions
 */
const cancelRedemption = async ({
  handleUpdatePoints,
  redemptionId,
  setRawRedemptions,
  userId,
}) => {
  try {
    await fetch(`/api/users/${userId}/redemptions/${redemptionId}`, {
      method: "DELETE",
    });
    setRawRedemptions((prev) =>
      prev.filter((redemption) => redemption.id !== redemptionId)
    );

    const points = await fetchUserPoints(userId);
    handleUpdatePoints(points);
  } catch (error) {
    console.error(error, strings.errors.failedToCancelRedemption);
  }
};

/**
 * Function to transform redemptions data
 * Clean up what's returned by the payload
 * @param {Array} redemptions - The redemptions array from the payload
 * @returns {Array} The transformed redemptions array
 */
function transformRedemptions(redemptions) {
  if (!redemptions || !redemptions.length) return [];
  return redemptions.map((redemption) => {
    return {
      id: redemption.id,
      createdAt: new Date(redemption?.created_at ?? "").toLocaleString(),
      isCancellable: redemption?.["cancellable?"] ?? false,
      name: redemption?.parsed_reward_snapshot?.name ?? "Unknown Reward",
      points: redemption?.points_spent ?? 0,
    };
  });
}
