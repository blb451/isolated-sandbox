import {
  render,
  screen,
  waitFor,
  act,
  fireEvent,
} from "@testing-library/react";
import { RedemptionHistory } from "./RedemptionHistory";
import { mockUsers, mockRedemptions } from "../../../../mockData";
import strings from "./strings";

describe("RedemptionHistory", () => {
  const props = {
    user: mockUsers[0],
    handleUpdatePoints: vi.fn(),
  };

  beforeEach(() => {
    vi.resetAllMocks();
    global.fetch = vi.fn((url) => {
      if (url.includes("/api/users/") && url.includes("/redemptions")) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockRedemptions),
        });
      }
      return Promise.reject(new Error(`Unexpected URL: ${url}`));
    });
  });

  it("shows error message when redemptions fail to load", async () => {
    global.fetch = vi.fn(() =>
      Promise.reject(new Error(strings.errors.failedToFetchRedemptions))
    );

    const originalError = console.error;
    console.error = vi.fn();

    await act(() => {
      render(<RedemptionHistory {...props} />);
    });

    await waitFor(() => {
      expect(
        screen.getByTestId("redemption-history-error-message")
      ).toHaveTextContent(strings.errors.failedToFetchRedemptions);
    });

    console.error = originalError;
  });

  it("shows loading message when redemptions are loading", async () => {
    global.fetch = vi.fn(() =>
      Promise.resolve({
        ok: false,
        status: 500,
      })
    );

    const originalError = console.error;
    console.error = vi.fn();

    render(<RedemptionHistory {...props} />);

    await waitFor(() => {
      expect(
        screen.getByTestId("redemption-history-loading-message")
      ).toBeInTheDocument();
    });

    console.error = originalError;
  });

  it("shows empty message when no redemptions are found", async () => {
    global.fetch = vi.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve([]),
      })
    );

    await act(() => {
      render(<RedemptionHistory {...props} />);
    });

    expect(
      screen.getByTestId("redemption-history-empty-message")
    ).toBeInTheDocument();
  });

  it("shows redemptions when loaded", async () => {
    await act(() => {
      render(<RedemptionHistory {...props} />);
    });

    await waitFor(() => {
      const redemptionItems = screen.getAllByTestId(/^redemption-item-\d+$/);
      expect(redemptionItems).toHaveLength(mockRedemptions.length);
    });
  });
});
