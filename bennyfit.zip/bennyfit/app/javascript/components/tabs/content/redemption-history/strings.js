export default {
    noRedemptionsMessage: "No redemptions found.",
    getRedemptionDateLabel: (redemption) => `Redeemed on ${redemption.createdAt}`,
    cancelRedemptionButtonLabel: "Cancel Redemption",
    redeemedLabel: "Redeemed",
    getPointsLabel: (points) => `-${points} points`,
    cancelButtonLabel: "Cancel",
    loadingMessage: "Loading redemptions...",
    emptyMessage: "No redemptions found.",
    errors: {
        failedToFetchRedemptions: "Failed to fetch redemptions",
    },
}