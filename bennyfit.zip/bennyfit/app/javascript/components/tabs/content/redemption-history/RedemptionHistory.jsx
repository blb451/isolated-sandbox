import { Fragment } from "react";
import PropTypes from "prop-types";
import { Divider } from "../../../common/Divider";
import { redemptionPropType, userPropType } from "../utils/prop-types";
import { useRedemptions } from "./use-redemptions";
import strings from "./strings";

export function RedemptionHistory({ user = null, handleUpdatePoints }) {
  const { redemptions, cancelRedemption, loading, error } = useRedemptions({
    user,
    handleUpdatePoints,
  });

  if (loading)
    return (
      <div data-testid="redemption-history-loading-message">
        {strings.loadingMessage}
      </div>
    );

  if (error)
    return <div data-testid="redemption-history-error-message">{error}</div>;

  if (redemptions.length === 0)
    return (
      <div data-testid="redemption-history-empty-message">
        {strings.emptyMessage}
      </div>
    );

  return (
    <div
      data-testid="redemption-history"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "1rem",
        border: "1px solid black",
        borderRadius: "4px",
        padding: "0 1rem",
      }}
    >
      {redemptions.map((redemption, index) => (
        <Fragment key={redemption.id}>
          <RedemptionItem
            redemption={redemption}
            cancelRedemption={cancelRedemption}
          />
          {index !== redemptions.length - 1 ? (
            <Divider />
          ) : (
            <div style={{ marginBottom: "1rem" }} />
          )}
        </Fragment>
      ))}
    </div>
  );
}

function RedemptionItem({ redemption, cancelRedemption }) {
  return (
    <div
      data-testid={`redemption-item-${redemption.id}`}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0.5rem 0",
      }}
    >
      <div>
        <h2 data-testid="redemption-name">{redemption.name}</h2>
        <p
          data-testid="redemption-date"
          style={{
            fontSize: "0.875rem",
            color: "gray",
          }}
        >
          {strings.getRedemptionDateLabel(redemption)}
        </p>
      </div>
      <div style={{ textAlign: "right" }}>
        <p
          data-testid="redemption-points"
          style={{
            fontWeight: 600,
            marginBottom: "0.5rem",
          }}
        >
          {strings.getPointsLabel(redemption.points)}
        </p>
        {redemption.isCancellable ? (
          <button
            data-testid={`cancel-redemption-${redemption.id}`}
            style={{
              backgroundColor: "black",
              color: "white",
              borderRadius: "1000px",
              border: "none",
              padding: "0.25rem 1rem",
              cursor: "pointer",
            }}
            onClick={() => cancelRedemption(redemption.id)}
          >
            Cancel
          </button>
        ) : (
          <div
            data-testid="redemption-status"
            style={{
              backgroundColor: "gray",
              color: "white",
              borderRadius: "1000px",
              padding: "0.25rem 1rem",
              display: "inline-block",
            }}
          >
            {strings.redeemedLabel}
          </div>
        )}
      </div>
    </div>
  );
}

RedemptionHistory.propTypes = {
  user: userPropType,
  handleUpdatePoints: PropTypes.func.isRequired,
};

RedemptionItem.propTypes = {
  cancelRedemption: PropTypes.func.isRequired,
  redemption: redemptionPropType.isRequired,
};
