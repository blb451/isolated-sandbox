import PropTypes from "prop-types";

// I'm more of a fan of TypeScript but PropTypes are still an 
// okay way of ensuring type safety in React components
export const userPropType = PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    points: PropTypes.number.isRequired,
});

export const rewardPropType = PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    isExpensive: PropTypes.bool.isRequired,
    pointsRequired: PropTypes.number.isRequired,
});
    
export const redemptionPropType = PropTypes.shape({
    id: PropTypes.number.isRequired,
    points: PropTypes.number.isRequired,
    createdAt: PropTypes.string.isRequired,
    isCancellable: PropTypes.bool.isRequired,
    name: PropTypes.string.isRequired,
});