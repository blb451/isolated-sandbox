/**
 * Fetches the points for a specific user
 * The alternative route would be to fetch this in the api calls for the 
 * redemptions' create and destroy actions, but I preferred to keep the 
 * api calls simple and this 
 * one results in a trivial payload response
 * 
 * P.S. I mentioned earlier that I don't mind fetch calls in simple cases
 * but outside of useEffects in react, I almost always default to them
 * especially in utils files, cause I know I'll most likely be doing the
 * try/catch block elsewhere
 * 
 * a small note I made to myself is that given how much I use the user 
 * data, ReactContext is a route that could be considered but I think 
 * it's overkill for the demo
 * @param {number} userId 
 * @returns {Promise<number>} The points for the user
 */
export async function fetchUserPoints(userId) {
    const response = await fetch(`/api/users/${userId}/points`);
    const { points } = await response.json();
    return points;
}
    
