export default {
    expensiveMessage: "Not enough points to redeem this reward",
    redeemNowButtonLabel: "Redeem now",
    rewardPointsRequiredMessage: (points) => `${points} points`,
    emptyMessage: "No rewards found",
    loadingMessage: "Loading rewards",
    errors: {
        failedToFetchRewards: "Failed to fetch rewards",
        failedToRedeemReward: "Failed to redeem reward",
    },
};
