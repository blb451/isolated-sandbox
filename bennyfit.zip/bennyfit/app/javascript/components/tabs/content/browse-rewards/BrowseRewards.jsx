import PropTypes from "prop-types";
import { rewardPropType, userPropType } from "../utils/prop-types";
import { useRewards } from "./use-rewards";
import strings from "./strings";

export function BrowseRewards({ user = null, handleUpdatePoints }) {
  const { error, loading, rewards, redeemReward } = useRewards({
    handleUpdatePoints,
    user,
  });

  if (loading)
    return (
      <div data-testid="browse-rewards-loading-message">
        {strings.loadingMessage}
      </div>
    );

  if (error)
    return <div data-testid="browse-rewards-error-message">{error}</div>;

  if (rewards.length === 0)
    return (
      <div data-testid="browse-rewards-empty-message">
        {strings.emptyMessage}
      </div>
    );

  return (
    <div
      data-testid="browse-rewards-grid"
      style={{
        display: "grid",
        gap: "1rem",
        gridTemplateColumns: "repeat(2, 1fr)",
      }}
    >
      {rewards.map((reward) => (
        <Card key={reward.id} reward={reward} redeemReward={redeemReward} />
      ))}
    </div>
  );
}

function Card({ redeemReward, reward }) {
  return (
    <div
      data-testid={`reward-card-${reward.id}`}
      style={{
        border: "1px solid black",
        padding: "1rem",
        borderRadius: "4px",
      }}
    >
      <h2 data-testid="reward-name">{reward.name}</h2>
      <p data-testid="reward-points-required">
        {strings.rewardPointsRequiredMessage(reward.pointsRequired)}
      </p>
      {reward.isExpensive ? (
        <p data-testid="reward-expensive-message">{strings.expensiveMessage}</p>
      ) : (
        <button
          data-testid={`redeem-button-${reward.id}`}
          onClick={() => redeemReward(reward.id)}
        >
          {strings.redeemNowButtonLabel}
        </button>
      )}
    </div>
  );
}

BrowseRewards.propTypes = {
  user: userPropType,
  handleUpdatePoints: PropTypes.func.isRequired,
};

Card.propTypes = {
  reward: rewardPropType,
  redeemReward: PropTypes.func.isRequired,
};
