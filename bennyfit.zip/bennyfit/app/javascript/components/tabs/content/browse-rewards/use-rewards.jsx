import { useState, useEffect, useMemo } from "react";
import { fetchUserPoints } from "../utils/api/queries";
import strings from "./strings";

/**
 * Custom hook for managing rewards
 * @param {Object} user - The user object
 * @param {function} handleUpdatePoints - Function to update points
 * @returns {Object} An object containing rewards and redeemReward function
 */
export function useRewards({ handleUpdatePoints, user }) {
  const [rawRewards, setRawRewards] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchRewards() {
      try {
        setLoading(true);
        const response = await fetch("/api/rewards");
        if (!response.ok) throw new Error(strings.errors.failedToFetchRewards);

        const data = await response.json();
        setRawRewards(data);
      } catch (error) {
        console.error(error.message);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    fetchRewards();
  }, []);

  // Memoize the data to prevent unnecessary re-renders after transforms
  // helpful in situations where more rewards are added or if user data is editable
  const rewards = useMemo(
    () => transformRewards(rawRewards, user),
    [rawRewards, user]
  );

  return {
    error,
    loading,
    rewards,
    redeemReward: (rewardId) =>
      redeemReward({
        rewardId,
        setError,
        userId: user?.id,
        handleUpdatePoints,
      }),
  };
}

/**
 * Function to redeem a reward
 * Additionally, update user points in the ui after creating redemptions
 * @param {number} rewardId - The id of the reward to redeem
 * @param {function} handleUpdatePoints - Function to update points
 * @param {function} setError - Function to set error
 * @param {number} userId - The id of the user
 */
const redeemReward = async ({
  rewardId,
  handleUpdatePoints,
  setError,
  userId,
}) => {
  try {
    await fetch(`/api/users/${userId}/redemptions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ reward_id: rewardId }),
    });

    const points = await fetchUserPoints(userId);
    handleUpdatePoints(points);
  } catch (error) {
    console.error(error, strings.errors.failedToRedeemReward);
    setError(strings.errors.failedToRedeemReward);
  }
};

/**
 * Function to transform rewards data
 * Add a few properties to the rewards array to make it easier to work with in the ui
 * pointsRequired is converted from snake_case to camelCase
 * isExpensive is a boolean that checks if the user has enough points to redeem the
 * reward, potential overoptimization but should be okay given the memoization
 * @param {Array} rewards - The rewards array from the payload
 * @param {Object} user - The user object
 * @returns {Array} The transformed rewards array
 */
function transformRewards(rewards, user) {
  if (!rewards || !rewards.length) return [];
  return rewards.map((reward) => {
    return {
      ...reward,
      isExpensive: reward?.points_required > user?.points,
      pointsRequired: reward?.points_required ?? 0,
    };
  });
}
