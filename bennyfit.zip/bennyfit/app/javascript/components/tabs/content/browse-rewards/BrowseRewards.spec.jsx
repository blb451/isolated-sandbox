import {
  render,
  fireEvent,
  screen,
  waitFor,
  act,
} from "@testing-library/react";
import { BrowseRewards } from "./BrowseRewards";
import { mockRewards, mockUsers } from "../../../../mockData";
import strings from "./strings";

describe("BrowseRewards", () => {
  const props = {
    user: mockUsers[0],
    handleUpdatePoints: vi.fn(),
  };

  beforeEach(() => {
    vi.resetAllMocks();
    global.fetch = vi.fn((url) => {
      if (url === "/api/rewards") {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockRewards),
        });
      }
      return Promise.reject(new Error(`Unexpected URL: ${url}`));
    });
  });

  it("shows error message when rewards fail to load", async () => {
    global.fetch = vi.fn(() =>
      Promise.reject(new Error("Failed to fetch rewards"))
    );

    const originalError = console.error;
    console.error = vi.fn();

    render(<BrowseRewards {...props} />);

    await waitFor(() => {
      expect(
        screen.getByTestId("browse-rewards-error-message")
      ).toBeInTheDocument();
    });

    console.error = originalError;
  });

  it("shows loading message when rewards are loading", async () => {
    global.fetch = vi.fn(() =>
      Promise.resolve({
        ok: false,
        status: 500,
      })
    );

    const originalError = console.error;
    console.error = vi.fn();

    render(<BrowseRewards {...props} />);

    await waitFor(() => {
      expect(
        screen.getByTestId("browse-rewards-loading-message")
      ).toBeInTheDocument();
    });

    console.error = originalError;
  });

  it("displays no rewards message when no rewards are found", async () => {
    global.fetch = vi.fn(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve([]),
      })
    );

    await act(() => {
      render(<BrowseRewards {...props} />);
    });

    expect(
      screen.getByTestId("browse-rewards-empty-message")
    ).toBeInTheDocument();
  });

  it("displays rewards when loaded", async () => {
    await act(() => {
      render(<BrowseRewards {...props} />);
    });

    await waitFor(() => {
      const rewardCards = screen.getAllByTestId(/^reward-card-\d+$/);
      expect(rewardCards).toHaveLength(mockRewards.length);

      mockRewards.forEach((reward, index) => {
        const rewardName = screen.getAllByTestId("reward-name")[index];
        const rewardPoints = screen.getAllByTestId("reward-points-required")[
          index
        ];

        expect(rewardName).toHaveTextContent(reward.name);
        expect(rewardPoints).toHaveTextContent(
          strings.rewardPointsRequiredMessage(reward.points_required)
        );
      });
    });
  });

  it("shows message when user doesn't have enough points", async () => {
    const expensiveRewardsCount = mockRewards.filter(
      (reward) => reward.points_required > props.user.points
    ).length;

    await act(() => {
      render(<BrowseRewards {...props} />);
    });

    await waitFor(() => {
      const expensiveMessages = screen.getAllByTestId(
        "reward-expensive-message"
      );
      expect(expensiveMessages).toHaveLength(expensiveRewardsCount);
    });
  });

  it("shows redeem button when user has enough points", async () => {
    const redeemableRewardsCount = mockRewards.filter(
      (reward) => reward.points_required <= props.user.points
    ).length;

    await act(() => {
      render(<BrowseRewards {...props} />);
    });

    await waitFor(() => {
      const redeemButtons = screen.getAllByTestId(/^redeem-button-\d+$/);
      expect(redeemButtons).toHaveLength(redeemableRewardsCount);
    });
  });

  it("calls redeemReward when redeem button is clicked", async () => {
    const firstReward = mockRewards.find(
      (reward) => reward.points_required <= props.user.points
    );

    global.fetch = vi
      .fn()
      .mockImplementationOnce((url) => {
        if (url === "/api/rewards") {
          return Promise.resolve({
            ok: true,
            json: () => Promise.resolve(mockRewards),
          });
        }
        return Promise.reject(new Error(`Unexpected URL: ${url}`));
      })
      .mockImplementationOnce((url) => {
        if (url === `/api/users/${props.user.id}/redemptions`) {
          return Promise.resolve({
            ok: true,
            json: () =>
              Promise.resolve({
                id: 1,
                points_spent: firstReward.points_required,
                reward_snapshot: firstReward,
                created_at: new Date().toISOString(),
                cancellable_until: new Date(
                  Date.now() + 30 * 60 * 1000
                ).toISOString(),
              }),
          });
        }
        return Promise.reject(new Error(`Unexpected URL: ${url}`));
      })
      .mockImplementationOnce((url) => {
        if (url.includes("/api/users/") && url.endsWith("/points")) {
          return Promise.resolve({
            ok: true,
            json: () =>
              Promise.resolve(props.user.points - firstReward.points_required),
          });
        }
        return Promise.reject(new Error(`Unexpected URL: ${url}`));
      });

    await act(() => {
      render(<BrowseRewards {...props} />);
    });

    await waitFor(() => {
      expect(
        screen.getByTestId(`redeem-button-${firstReward.id}`)
      ).toBeInTheDocument();
      fireEvent.click(screen.getByTestId(`redeem-button-${firstReward.id}`));
    });

    expect(global.fetch).toHaveBeenCalledWith(
      `/api/users/${props.user.id}/redemptions`,
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ reward_id: firstReward.id }),
      })
    );
    expect(props.handleUpdatePoints).toHaveBeenCalledTimes(1);
  });
});
