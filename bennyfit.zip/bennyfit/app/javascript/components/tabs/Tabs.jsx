import PropTypes from "prop-types";

export const labels = ["Browse Rewards", "Redemption History"];
export const getTestLabelId = (label) =>
  `tab-${label.toLowerCase().replace(/\s+/g, "-")}`;
export const defaultTabLabel = labels[0];

/**
 * Simple ui for swapping between tabs
 * @param {Object} props - The props object
 * @param {string} props.activeTab - The active tab
 * @param {function} props.setActiveTab - Function to set the active tab
 * @returns {JSX.Element} The Tabs component
 */
export function Tabs({ activeTab, setActiveTab }) {
  return (
    <div
      style={{
        backgroundColor: "lightgray",
        borderRadius: "4px",
        display: "grid",
        gridTemplateColumns: `repeat(${labels.length}, minmax(0, 1fr))`,
        width: "100%",
        padding: "0.25rem",
        gap: "0.25rem",
      }}
    >
      {labels.map((label) => {
        const testId = getTestLabelId(label);
        return (
          <Button
            key={label}
            onClick={() => setActiveTab(label)}
            label={label}
            active={activeTab === label}
            data-testid={testId}
          />
        );
      })}
    </div>
  );
}

function Button({ onClick, label, active, ...props }) {
  return (
    <button
      style={{
        backgroundColor: active ? "white" : "transparent",
        color: active ? "black" : "white",
        padding: "0.375rem 0.75rem",
        borderRadius: "4px",
        border: "none",
        cursor: "pointer",
        fontSize: "0.875rem",
        lineHeight: "1.25rem",
        fontWeight: "500",
        transition: "all 150ms ease",
        gap: "0.5rem",
        display: "flex",
        justifyContent: "center",
      }}
      onClick={onClick}
      {...props}
    >
      {label}
    </button>
  );
}

Tabs.propTypes = {
  activeTab: PropTypes.oneOf(labels).isRequired,
  setActiveTab: PropTypes.func.isRequired,
};

Button.propTypes = {
  onClick: PropTypes.func.isRequired,
  label: PropTypes.string.isRequired,
  active: PropTypes.bool.isRequired,
};
