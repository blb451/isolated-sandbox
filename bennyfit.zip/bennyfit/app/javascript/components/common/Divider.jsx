export function Divider() {
  return (
    <div
      style={{
        height: "1px",
        backgroundColor: "black",
      }}
    />
  );
}
