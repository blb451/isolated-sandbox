class Api::RedemptionsController < Api::BaseController
    include Api::RedemptionsHelper
    before_action :set_user
    before_action :set_redemption, only: [ :destroy ]

    class InsufficientPointsError < StandardError; end
    class CancellationWindowExpiredError < StandardError; end

    def index
      @redemptions = @user.redemptions.includes(:reward).order(created_at: :desc)
      render json: @redemptions.as_json(methods: [ :cancellable?, :parsed_reward_snapshot ])
    end

    def create
      ActiveRecord::Base.transaction do
        reward = Reward.find(params[:reward_id])
        raise InsufficientPointsError if @user.points < reward.points_required
        @redemption = @user.redemptions.create!(
          reward_id: params[:reward_id],
          cancellable_until: cancellation_window.from_now
        )
        @user.update!(points: @user.points - reward.points_required)
      end
      render json: @redemption.as_json, status: :created
    end

    def destroy
      ActiveRecord::Base.transaction do
        raise CancellationWindowExpiredError unless @redemption.cancellable?
        @user.update!(points: @user.points + @redemption.points_spent)
        @redemption.destroy!
      end
      head :no_content
    end

    RESCUE_ORDER = [
      ActiveRecord::RecordInvalid,
      ActiveRecord::RecordNotFound,
      InsufficientPointsError,
      CancellationWindowExpiredError,
      StandardError
    ].freeze

    rescue_from *RESCUE_ORDER, with: :handle_error

    private

    def handle_error(e)
      status, message = case e
      when ActiveRecord::RecordInvalid then [ :unprocessable_entity, e.record.errors.full_messages ]
      when ActiveRecord::RecordNotFound then [ :not_found, error_messages[:redemption_not_found] ]
      when InsufficientPointsError then [ :forbidden, error_messages[:insufficient_points] ]
      when CancellationWindowExpiredError then [ :forbidden, error_messages[:cancellation_window_expired] ]
      else [ :internal_server_error, "Something went wrong" ]
      end

      log_error(e) unless status == :not_found # Don't log simple 404s
      render json: { error: message }, status: status
    end

    def log_error(e)
      Rails.logger.error("Redemption Error: #{e.message}\n#{e.backtrace.join("\n")}")
    end

    def set_user
      @user = User.find(params[:user_id])
    end


    def set_redemption
      @redemption = @user.redemptions.find(params[:id])
    rescue ActiveRecord::RecordNotFound
      render json: { error: "Redemption not found" }, status: :not_found
    end
end
