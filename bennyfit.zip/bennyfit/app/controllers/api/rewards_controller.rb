class Api::RewardsController < Api::BaseController
    def index
        @rewards = Reward.all
        render json: @rewards
    end
end
