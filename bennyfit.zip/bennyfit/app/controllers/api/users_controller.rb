class Api::UsersController < Api::BaseController
    def index
        @users = User.all
        render json: @users
    end

    def show
        @user = User.includes(:redemptions).find(params[:id])
        render json: @user.as_json(include: :redemptions)
    end

    def points
        @user = User.find(params[:id])
        render json: { points: @user.points }
    end
end
