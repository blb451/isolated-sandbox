module Api::RedemptionsHelper
    def cancellation_window
        1.hour
    end

    def error_messages
        {
            insufficient_points: "Insufficient points",
            cancellation_window_expired: "Cancellation window expired",
            redemption_not_found: "Redemption not found"
        }
    end
end
