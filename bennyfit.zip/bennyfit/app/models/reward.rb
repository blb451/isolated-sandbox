class Reward < ApplicationRecord
    has_many :redemptions

    # zero/negative points doesn't make sense for our use case
    validates :points_required, presence: true, numericality: { greater_than: 0 }
    validates :name, presence: true
end
