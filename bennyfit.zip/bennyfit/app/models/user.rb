class User < ApplicationRecord
    has_many :redemptions
    has_many :rewards, through: :redemptions
    validates :points, presence: true, numericality: { greater_than_or_equal_to: 0 }
    validates :name, presence: true
end
