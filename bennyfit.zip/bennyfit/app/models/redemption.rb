class Redemption < ApplicationRecord
    belongs_to :user
    belongs_to :reward

    before_validation :capture_reward_snapshot, on: :create

    validates :points_spent, presence: true, numericality: { greater_than: 0 }
    validates :reward_snapshot, presence: true

    def cancellable?
      cancellable_until.nil? || cancellable_until > Time.current
    end

    def parsed_reward_snapshot
      return if reward_snapshot.blank?
      case reward_snapshot
      when String
        JSON.parse(reward_snapshot)
      when Hash
        reward_snapshot
      else
        Rails.logger.error("Invalid reward_snapshot type: #{reward_snapshot.class}")
        {}
      end
    end

    private

    def capture_reward_snapshot
      return if reward.blank?

      self.points_spent = reward.points_required
      self.reward_snapshot = reward.to_json
    end
end
