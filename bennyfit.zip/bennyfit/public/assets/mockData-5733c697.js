// app/javascript/mockData.js
var mockUsers = [
  {
    id: 1,
    name: "Reed",
    points: 1e3
  },
  {
    id: 2,
    name: "Sue",
    points: 500
  }
];
var mockRewards = [
  { id: 1, name: "Uniform Upgrade", points_required: 365 },
  { id: 2, name: "Omegadrive", points_required: 230 },
  { id: 3, name: "Hulk Assist", points_required: 2432 }
];
var mockRedemptions = [
  {
    "id": 14,
    "user_id": 2,
    "reward_id": 1,
    "cancellable_until": "2025-07-25T20:23:31.307Z",
    "points_spent": 365,
    "reward_snapshot": '{"id":1,"name":"Uniform Upgrade","points_required":365,"created_at":"2025-07-23T22:40:24.475Z","updated_at":"2025-07-23T22:40:24.475Z"}',
    "created_at": "2025-07-25T20:21:31.308Z",
    "updated_at": "2025-07-25T20:21:31.308Z",
    "cancellable?": false,
    "parsed_reward_snapshot": {
      "id": 1,
      "name": "Uniform Upgrade",
      "points_required": 365,
      "created_at": "2025-07-23T22:40:24.475Z",
      "updated_at": "2025-07-23T22:40:24.475Z"
    }
  },
  {
    "id": 13,
    "user_id": 2,
    "reward_id": 2,
    "cancellable_until": "2026-07-25T20:23:10.100Z",
    "points_spent": 230,
    "reward_snapshot": '{"id": 2,"name":"Omegadrive","points_required":230,"created_at":"2025-07-23T22:40:24.476Z","updated_at":"2025-07-23T22:40:24.476Z"}',
    "created_at": "2026-07-25T20:21:10.102Z",
    "updated_at": "2026-07-25T20:21:10.102Z",
    "cancellable?": true,
    "parsed_reward_snapshot": {
      "id": 2,
      "name": "Omegadrive",
      "points_required": 230,
      "created_at": "2025-07-23T22:40:24.476Z",
      "updated_at": "2025-07-23T22:40:24.476Z"
    }
  }
];
export {
  mockRedemptions,
  mockRewards,
  mockUsers
};
//# sourceMappingURL=/assets/mockData-bbb06ca5.js.map
