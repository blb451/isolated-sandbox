# take home implementation

implement a basic rewards redemption web app that allows a user to do the following:

- View their current reward points balance. → balance comes from user table
- Browse available rewards. → via accessing the rewards table
- Redeem rewards using their points.
- See a history of their reward redemptions. → via accessing redemptions table.
    - user.redemptions.includes(reward).order(redeemed_at, descending order?
    - for simplicity user cannot change the order
- Stretch goals:
    - cancel a redemption (admin user can carry this out, let’s give Galactus this capability)
        - simplified the functionality to allow any user to cancel redemptions
        - Galactus will be our admin user. He can view summaries of other user’s information e.g. name, points. I think the way cancellation works here is there’s a time frame in which a redemption occurs. So their view would include this timeframe and something in the ui saying if there was a cancellation request or not. A cancellation request should change the status of the reward immediately.
        - Galactus can also change reward information. If a reward is expired there must be a reason
    - add ability to earn points (simple counter)
        - Not achieved
    - setup a reward card and give rewards descriptive images (Download an icon library to handle these? or use raw svgs)
        - didn’t implement images for rewards
- Frontend
    
    UI can either be in Ruby or in React. The functionality seems simple enough that I could work on carrying out in Ruby but given the time allocated for the assignment and the fact that I’m pretty comfortable with React, I’ll go with a React SPA where Ruby acts as the json api. This is similar to how development was setup back at Aurora Solar (albeit there was a mix of Ruby and React UIs). 
    
- Database structure
    
    
    | User |  |
    | --- | --- |
    | id | integer |
    | name | text |
    | points | integer |
    
    | Rewards |  |
    | --- | --- |
    | id | integer |
    | name | text |
    | points_required | integer |
    | ~~image_url~~ | ~~image?~~ |
    
    | Redemptions |  |
    | --- | --- |
    | id | integer |
    | reward_snapshot | json |
    | cancellable_until | datetime |
    | points_spent | integer |
- Model Information
    
    User has many redemptions, and rewards through redemptions and can have 0 or more points
    Rewards have many redemptions, and their points must be greater than 0
    Redemption belongs to user and reward and has a snapshot that tracks the status of a reward at a particular point in time for auditing purposes
    
    User and Reward should be foreign keys for the Redemption table
    
    Index: redemptions table, one for reward id and another for user id
    
    ~~indexes?~~
    
    - ~~cancellation requests~~
    - ~~reward status for redemption history~~
    - ~~reward visibility filter? based off of points required~~
    - ~~expiration?~~

Seed: User names and Rewards list, 

- ~~admin can allocate points~~
- allocate random amounts of points

~~Possible Redemption Statuses → successful (reward has been redeemed, no takebacksies), **active** (default, user has attempted to redeem a reward, user had a cancellation request for a reward but they cancelled said request), pending (there is a cancellation request and of course, in the time it takes to verify the reward is good to go, the user can cancel their cancellation request before the admin sees it), cancelled (admin saw the cancellation request and cancelled the redemption), rejected (maybe the reward is out of stock? points should be returned to user)~~

~~User has a reward history ie their reward history belongs to them
After a reward is redeemed, your reward history is updated~~

- ~~alt: every time you redeem a reward, you create a record of redeemed_reward linked to the user that has a date_time, filtering this table might be expensive?~~

Rewards: Hulk Assist, Uniform Upgrade, Omegadrive, Airjet-Cycle Driver’s Seat , Universal Translator, Baxter Building Guest Pass, Spider-Man Shoutout, Avengers Identicard, Hammer of Angrir, Fake Micro-Galaxy Ring, Cosmic Control Rod, Memorium Device

Users: Reed, Sue, Johnny, Ben

~~We want to randomly select one of each user on accessing the web app. An unlikely stretch goal could be to have some sort of login functionality or a way to intelligently swap between users~~

- Ended up implementing a user dropdown, and defaulting to the first user in the dropdown

I think we can check in the seeds into version control since this is strictly for development

- ~~Investigate using faker if there’s time at the end of the project~~

routes: will this be one page with all the information?

- used tabs instead of routes for simplicity
- ~~alternative: route for history, route for user information (where they would see their points), route where they can redeem rewards~~
- tests
    
    can a user redeem rewards on 0 points, what happens
    
    what happens on attempting to redeem rewards in general
    
    how do we handle rewards that are too expensive for them
    
    points display correctly rendered on ui
    
    list of rewards correctly rendered on ui
    
    redemption history is viewable
    
    routes work correctly?
    
    points should be restored on cancellation
    
    expired rewards don’t show up in the list? or if they do there should be an explanation for why they’re expired
    
    reward information can be updated by admin user → check if there’s a reward snapshot to compare to updated reward?
    
- considerations
    
    using `bigint` for ids would be optimal for future scalability
    
    auditing via snapshots: given the fact that we might change reward information in the future, we can save information about the reward in the redemption record. 
    
    This will be be particularly helpful in a world where some rewards become inaccessible to users maybe because they were seasonal (there could be datetime fields attached to rewards for this, but that can be a stretch goal), or they were relevant to a region but no longer are. Also all the fields for rewards could change. Functionality for the admin user
    
    We should add a simple field indicating viewability to the reward table and test that out along the line. I imagine in the real world that would be more of an “expired” state for individual rewards? Maybe it would be an expired field? and we could also have an expiry_explanation field?
    
    use foreign keys to avoid orphaned records
    
    we need validation on Rewards to prevent creation of rewards that require zero/negative points
    
    when would we graduate from sqlite
    
    - PostgreSQL: jsonb supports indexing, useful for the reward_snapshot field.
        - Would probably use gin index for jsonb? It’s a more effective way of querying nested json data
    - Locking: this will be useful for preventing double spending/double cancellations (potential deadlocks)
    - Retry logic
    - Reward availability?

    ```mermaid
    stateDiagram-v2
    [*] --> created: (lock user+reward)
    created --> cancelled: attempt_to_cancel(lock redemption+user)
    created --> redeemed: automatic_after_30min
    cancelled --> [*]: release locks
    redeemed --> [*]: release locks
    
    note left of created: Locking Protocol:
    1. Lock user FIRST
    2. Then lock reward
    3. Process transaction
    ```

    ```mermaid
    stateDiagram-v2
    [*] --> redeem_reward
    redeem_reward --> check_lock: (acquire user lock)
    check_lock --> redeemed: points_sufficient\n(lock reward)
    check_lock --> warning: points_insufficient\n(release lock)
    redeemed --> create_redemption: (hold locks)
    create_redemption --> [*]: commit transaction\nrelease locks
    warning --> [*]: release lock
    
    note right of check_lock: Locking Order:
    1. User lock
    2. Reward lock
    3. Process
    4. Release in reverse order
    ```

Deployment:

- Use netlify/**render**/heroku/fly.io → ended up going with render
  - [https://bennyfits.onrender.com/](https://bennyfits.onrender.com/)
- Connect to the github repo
- No need to setup an `.env` file

Reminders: Models care about data integrity, Controllers care about business rules, coordination between different models

Implement minimal Appropriate Loading & Error States for api calls on the frontend

- ~~Consider react-query~~