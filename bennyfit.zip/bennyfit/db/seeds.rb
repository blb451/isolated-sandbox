# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end

[ "Reed", "Sue", "Johnny", "Ben" ].each do |name|
    User.find_or_create_by!(name: name, points: Random.new.rand(100..1000))
end

[ "Uniform Upgrade", "Omegadrive", "Hulk Assist", "Universal Translator", "Avengers Identicard" ].each do |name|
    Reward.find_or_create_by!(name: name, points_required: Random.new.rand(100..1000))
end
