class CreateRewards < ActiveRecord::Migration[8.0]
  def change
    create_table :rewards do |t|
      t.text :name, null: false
      t.integer :points_required, null: false

      t.timestamps
    end
  end
end
