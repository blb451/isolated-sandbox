class CreateRedemptions < ActiveRecord::Migration[8.0]
  def change
    create_table :redemptions do |t|
      t.references :user, foreign_key: true
      t.references :reward, foreign_key: true

      t.datetime :cancellable_until # When the redemption can be cancelled
      t.datetime :cancelled_at # When the redemption was cancelled
      t.integer :points_spent
      t.json :reward_snapshot

      t.timestamps

      t.index [ :user_id, :cancelled_at ], name: "index_user_active_redemptions"
    end
  end
end
