class RemoveDeadIndex < ActiveRecord::Migration[8.0]
  def change
    remove_index :redemptions, name: "index_user_active_redemptions"
  end
end
