class RemoveCancelledAtColumnFromRedemptions < ActiveRecord::Migration[8.0]
  def change
    remove_column :redemptions, :cancelled_at # taken care of on destroy
  end
end
