# Bennyfits (and Rewards) 🎁

A rewards redemption application built with Ruby on Rails and React.

## 🌐 Live Demo
[![Render](https://img.shields.io/badge/Render-Deployed-blue)](https://bennyfits.onrender.com/)
- Deployed on Render (free tier) - may take 30-60 seconds to wake up
- Test users available (see [Functionality](#-functionality))

## 🚀 Local Development

### Prerequisites
- Ruby 3.4.3
- Rails 8.0.2
- Node 24.4.1
- NPM 11.4.2
- Yarn 1.22.22
- SQLite3

### Installation
1. Clone the repository
2. Install dependencies:
   ```bash
   bundle install
   yarn install
   bin/rails assets:precompile
   ```
3. Set up the database: the seed file creates 4 test users with random points and 5 rewards with random points required
   ```bash
   bin/rails db:create db:migrate db:seed
   ```
4. Start the server:
   ```bash
   bin/dev
   ```

## 📚 Functionality
Some of the database details differ between local and live demo:
- 🔄 User Switching
    - 4 users available: Reed (who has barely any points), Sue, Johnny, Ben
	- Use the dropdown in the top-right corner
	- Points balance updates in real-time
- 📦 Tabs
	- Cycle through tabs to browse through rewards or view the user's redemption history
- 🎁 Rewards
	- 5-7 available rewards
	- Real-time point balance validation
	- Visual indicators for affordable/unaffordable rewards
- ⏳ Redemptions
	- Cancellable for 30 minutes after creation
    - Visual timer on redemption cards
### Caveat
- Locking is not implemented in the application. This is a potential issue for concurrent requests. 

## 🧪 Testing
Run tests with:
```bash
yarn test
```

## 🛠 Troubleshooting
### Common issues
1. Assets not updating
```bash
yarn rebuild
```
Nuclear option:
```bash
bin/rails assets:clobber assets:precompile && bin/rails restart
```
2. Live Demo not working
- A 502 Bad Gateway error may occur if a deployment is in progress
- Wait for a couple minutes and try again


## 📝 Notes
- The 30 minute timer for redemptions is simulated for demo purposes

## 📡 API Endpoints
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/users` | GET | Get all users |
| `/api/users/:id` | GET | Get user by ID |
| `/api/users/:id/points` | GET | Get user points |
| `/api/users/:id/redemptions` | POST | Create new redemption |
| `/api/users/:id/redemptions/:id` | DELETE | Cancel redemption |
| `/api/rewards` | GET | Get all rewards |

### State Diagrams

#### Browse Rewards Interaction
```mermaid
stateDiagram-v2
    [*] --> attempt_redeem
    attempt_redeem --> success: if user.points >= reward.points_required
    attempt_redeem --> error_insufficient_points: if user.points < reward.points_required
    success --> create_redemption
    create_redemption --> [*]
    error_insufficient_points --> [*]
```

#### Redemption History Interaction
```mermaid
stateDiagram-v2
    [*] --> created
    created --> cancelled: user_cancels
    created --> redeemed: auto_after_30min
    created --> error_insufficient_points: if user.points < reward.points_required

    cancelled --> [*]
    cancelled --> error_cancel_failed: if server_error
    cancelled --> error_cancellation_expired: if >30min
    error_cancellation_expired --> redeemed
    redeemed --> [*]
    redeemed --> error_redeem_failed: if webhook_fails

    error_insufficient_points --> [*]
    error_cancel_failed --> [*]
    error_redeem_failed --> [*]
```



## 🛠 Technology Stack & Architecture
| Component | Choice | Rationale |
|-----------|--------|-----------|
| Frontend | React 18 | Interactive UI |
| Backend | Rails 8.0.2 (API Mode) | Fast JSON endpoints with mature ecosystem |
| Local DB | SQLite3 | Simplified development setup |
| Production DB | PostgreSQL (on Render) | Production-grade reliability |
| UI Toolkit | Inline styling | Simple and fast |
| Deployment | Render | Zero-config Rails deployment |

```mermaid
flowchart LR
    A[React SPA] -->|HTTP| B[Rails API]
    B --> C[(SQLite/PostgreSQL)]
```

### Potential Architectural Improvements
- Use Hotwire (Turbo/Stimulus) instead of React
  - This would have helped to avoid complexity and allow for faster feature iteration
  - Easier to achieve server-side state consistency for the point balances
- Use tailwindcss for styling
- Use postgresql for local database
  - Render doesn't support SQLite3
  - Allows for more user ids, since the type can be set to bigint
- Use redis for caching

### Future Functionality Improvements
- Add user roles (admin, user): to allowlow for an admin role who can update reward information. This was the intent behind the reward_snapshot field in the Redemption model
- Locking and retry logic for redemptions (analytics to track this as well)
- Validate if a user owns a redemption or not, before allowing them to destroy it
- Avoid duplicate requests via idempotency keys
- Use state machines in the models
- Handle Bad Request errors: when the params are invalid
- Move Error messages to a separate file/module (probably a concern)
- Reward status tied to an inventory count
- Allow users to earn points
- Sorting Rewards: would require an index on points_required
- Use shoulda matchers gem for validation tests
