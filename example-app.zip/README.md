# Todo Application - Take-Home Assignment

A simple full-stack Todo application built with Ruby on Rails (API) and React (Vite).

## Technology Stack

- **Backend**: Ruby on Rails 7.1.2 (API mode)
- **Frontend**: React 18 with Vite
- **Database**: SQLite3
- **HTTP Client**: Axios

## Prerequisites

- Ruby 3.2.2
- Node.js 18+ and npm
- SQLite3

## Setup Instructions

### Backend Setup (Rails API)

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Install Ruby dependencies:
   ```bash
   bundle install
   ```

3. Create and setup the database:
   ```bash
   rails db:create
   rails db:migrate
   rails db:seed
   ```

4. Start the Rails server:
   ```bash
   rails server
   ```
   
   The API will be available at `http://localhost:3000`

### Frontend Setup (React)

1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install Node dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

3. Start the development server:
   ```bash
   npm run dev
   # or
   yarn dev
   ```
   
   The frontend will be available at `http://localhost:5173`

## API Endpoints

- `GET /api/v1/todos` - List all todos
- `GET /api/v1/todos/:id` - Get a specific todo
- `POST /api/v1/todos` - Create a new todo
- `PATCH /api/v1/todos/:id` - Update a todo
- `DELETE /api/v1/todos/:id` - Delete a todo

## Features

- Create new todos
- Mark todos as complete/incomplete
- Delete todos
- Responsive design
- Real-time updates

## Project Structure

```
todo-takehome-app/
├── backend/              # Rails API
│   ├── app/
│   │   ├── controllers/
│   │   └── models/
│   ├── config/
│   ├── db/
│   └── Gemfile
├── frontend/             # React App
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
└── README.md
```

## Notes

- The backend runs on port 3000
- The frontend runs on port 5173 and proxies API requests to the backend
- CORS is configured to allow requests from the frontend
- Sample data is included via seeds

## Troubleshooting

If you encounter any issues:

1. Ensure both servers are running (Rails on 3000, Vite on 5173)
2. Check that all dependencies are installed
3. Verify the database is created and migrated
4. Clear browser cache if needed

## Author

Created as a take-home assignment demonstration