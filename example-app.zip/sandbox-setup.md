# Running Todo App in Sandbox

## Quick Setup Commands

Run these commands in the sandbox terminal:

### Backend (Rails API)
```bash
cd backend
bundle install
bundle exec rails db:create db:migrate db:seed
bundle exec rails server -b 0.0.0.0
```

### Frontend (React) - In a new terminal
```bash
cd frontend
yarn install

# Option 1: Direct API calls (if CORS is configured)
yarn dev --host

# Option 2: Use proxy (requires workaround)
# The Vite proxy doesn't work with --host flag
# You'll need to configure CORS in the backend instead
```

## Access the App
- Backend API: http://localhost:3000/api/v1/todos
- Frontend App: http://localhost:5173

## Troubleshooting

### If Rails gives an error about Ruby version:
```bash
asdf set ruby 3.2.2
```

### If database already exists:
```bash
bundle exec rails db:drop db:create db:migrate db:seed
```

### If ports are already in use:
The sandbox launcher will automatically assign alternative ports. Check the terminal output for the actual ports being used.