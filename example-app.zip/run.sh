#!/bin/bash

# Script to set up and run the Todo Take-Home App

echo "================================"
echo "Todo App Setup & Run Script"
echo "================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Backend setup
echo -e "${YELLOW}Setting up Backend (Rails API)...${NC}"
cd backend

# Install dependencies
echo "Installing Ruby gems..."
bundle install

# Database setup
echo "Setting up database..."
bundle exec rails db:create 2>/dev/null || echo "Database already exists"
bundle exec rails db:migrate
bundle exec rails db:seed 2>/dev/null || echo "Seed data may already exist"

# Start Rails server in background
echo -e "${GREEN}Starting Rails API server on port 3000...${NC}"
bundle exec rails server -b 0.0.0.0 &
RAILS_PID=$!

# Wait for Rails to start
sleep 3

# Frontend setup
echo ""
echo -e "${YELLOW}Setting up Frontend (React/Vite)...${NC}"
cd ../frontend

# Install dependencies
echo "Installing Node packages..."
if [ -f "yarn.lock" ]; then
    yarn install
else
    npm install
fi

echo ""
echo -e "${GREEN}Starting Vite dev server on port 5173...${NC}"
echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}✓ Backend API: http://localhost:3000${NC}"
echo -e "${GREEN}✓ Frontend App: http://localhost:5173${NC}"
echo -e "${GREEN}================================${NC}"
echo ""
echo "Press Ctrl+C to stop both servers"
echo ""

# Start Vite server (this will run in foreground)
if [ -f "yarn.lock" ]; then
    yarn dev --host
else
    npm run dev -- --host
fi

# Cleanup on exit
trap "kill $RAILS_PID 2>/dev/null" EXIT