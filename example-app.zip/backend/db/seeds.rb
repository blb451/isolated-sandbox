Todo.create([
  { title: "Complete take-home assignment", completed: false },
  { title: "Review Rails documentation", completed: true },
  { title: "Set up development environment", completed: true },
  { title: "Write unit tests", completed: false }
])