Rails.application.config.middleware.insert_before 0, Rack::Cors do
  allow do
    # Allow common development ports
    origins 'http://localhost:5173', 'http://localhost:5174', 
            'http://localhost:5175', 'http://localhost:5176',
            'http://localhost:5177', 'http://localhost:5178',
            'http://localhost:5179', 'http://localhost:5180',
            'http://localhost:5181', 'http://localhost:5182',
            'http://localhost:5183'
    
    resource '*',
      headers: :any,
      methods: [:get, :post, :put, :patch, :delete, :options, :head]
  end
end